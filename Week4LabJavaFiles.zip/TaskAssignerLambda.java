@FunctionalInterface
interface TaskAssigner {
    void assignTask(String student, String task);
}

public class TaskAssignerLambda {
    public static void main(String[] args) {
        // Using a Lambda expression to assign tasks
        TaskAssigner assigner = (student, task) -> 
            System.out.println("Student: " + student + "\nAssigned Task: " + task + "\n");

        // Demonstrate with three students
        assigner.assignTask("Alice", "Complete the Math worksheet");
        assigner.assignTask("Bob", "Write a Java program using functional interfaces");
        assigner.assignTask("Charlie", "Prepare a presentation on lambda expressions");
    }
}
