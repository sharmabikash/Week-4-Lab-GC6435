import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCConnectivityTest {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/student_tasks"; // Change if needed
        String user = "root"; // Your MySQL username
        String password = ""; // Your MySQL password

        try {
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to MySQL database successfully!");
            connection.close();
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
        }
    }
}
