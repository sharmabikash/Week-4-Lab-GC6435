import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TableDataPrinter {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/student_tasks"; 
        String user = "root";
        String password = "";

        try {
            Connection connection = DriverManager.getConnection(url, user, password);
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM tasks"; // Replace 'tasks' with your table name
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String studentName = resultSet.getString("student_name");
                String taskDescription = resultSet.getString("task_description");

                System.out.println("ID: " + id + ", Student: " + studentName + ", Task: " + taskDescription);
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }
}
